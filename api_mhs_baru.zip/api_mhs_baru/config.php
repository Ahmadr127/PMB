<?php
    define('DB_NAME', 'praktikum_mobile_platform');
    define('DB_USER', 'root');
    define('DB_PASSWORD', '');
    define('DB_HOST', 'localhost');

    $kon =mysqli_connect("localhost", "root", "", "praktikum_mobile_platform") or die(mysqli_error());
?>