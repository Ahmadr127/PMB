<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Origin, Content-Type, Authorization, Accept, X-Requested-With, x-xsrf-token");
header("Content-Type: application/json; charset=utf-8");

include "config.php";

$insert = mysqli_query($kon, "INSERT INTO tbl_mhs_rifai (
    `id`, `nama_mahasiswa`, `jenis_kelamin`, `nomor`, `email`,`asal_sekolah`,`prodi`,`jenjang`,`kelas`,`info`,`status`) 
    VALUES (
        '',
        '$_POST[nama_mahasiswa]',
        '$_POST[jenis_kelamin]',
        '$_POST[nomor]',
        '$_POST[email]',
        '$_POST[asal_sekolah]',
        '$_POST[prodi]',
        '$_POST[jenjang]',
        '$_POST[kelas]',
        '$_POST[info]',
        '0')");

if ($insert) {
    $result = json_encode(array('error' => false, 'msg' => 'Data Berhasil Disimpan '));
} else {
    $result = json_encode(array('error' => true, 'msg' => mysqli_error()));
}

echo $result;
?>
